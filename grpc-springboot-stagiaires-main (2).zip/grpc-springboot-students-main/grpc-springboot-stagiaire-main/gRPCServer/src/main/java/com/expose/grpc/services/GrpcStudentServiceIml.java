package com.expose.grpc.services;

import com.expose.entities.Stagiaire;
import com.expose.grpc.stubs.StagiaireOuterClass;
import com.expose.grpc.stubs.StagiaireOuterClass.*;
import com.expose.grpc.stubs.StagiaireServiceGrpc;
import com.expose.mappers.StagiaireMapper;
import com.expose.repositories.StagiaireRepository;
import io.grpc.Status;
import io.grpc.stub.StreamObserver;
import lombok.RequiredArgsConstructor;
import net.devh.boot.grpc.server.service.GrpcService;

import java.util.List;
import java.util.Stack;
import java.util.Timer;
import java.util.TimerTask;

@GrpcService
@RequiredArgsConstructor
public class GrpcStagiaireServiceIml extends StagiaireServiceGrpc.StagiaireServiceImplBase {

    private final StagiaireRepository StagiaireRepository;
    private final StagiaireMapper StagiaireMapper;

    @Override
    public void listStagiaires(Empty request, StreamObserver<ListStagiairesResponse> responseObserver) {
        List<Stagiaire> Stagiaires = StagiaireRepository.findAll();
        List<StagiaireOuterClass.Stagiaire> listStagiaires = Stagiaires.stream()
                .map(StagiaireMapper::toGrpcStagiaire)
                .toList();
        ListStagiairesResponse listStagiairesResponse = ListStagiairesResponse.newBuilder()
                .addAllStagiaires(listStagiaires)
                .build();
        responseObserver.onNext(listStagiairesResponse);
        responseObserver.onCompleted();
    }

    @Override
    public void listStagiairesStream(Empty request,
                                   StreamObserver<StagiaireOuterClass.Stagiaire> responseObserver) {
        List<Stagiaire> Stagiaires = StagiaireRepository.findAll();
        List<StagiaireOuterClass.Stagiaire> listStagiaires = Stagiaires.stream()
                .map(StagiaireMapper::toGrpcStagiaire)
                .toList();
        if (listStagiaires.isEmpty()) {
            responseObserver.onError(Status.INTERNAL.withDescription("no Stagiaire found").asException());
        } else {
            Stack<StagiaireOuterClass.Stagiaire> stackStagiaires = new Stack<>();
            stackStagiaires.addAll(listStagiaires);
            Timer timer = new Timer("Stagiaires timer");
            timer.schedule(new TimerTask() {

                @Override
                public void run() {
                    responseObserver.onNext(stackStagiaires.pop());
                    if (stackStagiaires.isEmpty()) {
                        responseObserver.onCompleted();
                        timer.cancel();
                    }
                }

            }, 0, 1000);
        }
    }

    @Override
    public void getStagiaire(GetStagiaireRequest request,
                           StreamObserver<StagiaireOuterClass.Stagiaire> responseObserver) {
        Stagiaire Stagiaire = StagiaireRepository.findById(request.getId()).orElse(null);
        if (Stagiaire == null) {
            responseObserver.onError(Status.INTERNAL.withDescription("Stagiaire not found").asException());
        } else {
            responseObserver.onNext(StagiaireMapper.toGrpcStagiaire(Stagiaire));
            responseObserver.onCompleted();
        }
    }

    @Override
    public void createStagiaire(CreateStagiaireRequest request,
                              StreamObserver<StagiaireOuterClass.Stagiaire> responseObserver) {
        Stagiaire Stagiaire = Stagiaire.builder().firstName(request.getFirstName()).lastName(request.getLastName()).age(request.getAge()).build();
        responseObserver.onNext(StagiaireMapper.toGrpcStagiaire(StagiaireRepository.save(Stagiaire)));
        responseObserver.onCompleted();
    }

    @Override
    public void updateStagiaire(StagiaireOuterClass.Stagiaire request,
                              StreamObserver<StagiaireOuterClass.Stagiaire> responseObserver) {
        if (StagiaireRepository.existsById(request.getId())) {
            Stagiaire Stagiaire = StagiaireRepository.save(StagiaireMapper.fromGrpcStagiaire(request));
            responseObserver.onNext(StagiaireMapper.toGrpcStagiaire(Stagiaire));
            responseObserver.onCompleted();
        } else {
            responseObserver.onError(Status.INTERNAL.withDescription("Stagiaire not found").asException());
        }
    }

    @Override
    public void deleteStagiaire(DeleteStagiaireRequest request,
                              StreamObserver<DeleteStagiaireResponse> responseObserver) {
        if (StagiaireRepository.existsById(request.getId())) {
            StagiaireRepository.deleteById(request.getId());
            DeleteStagiaireResponse deleteStagiaireResponse = DeleteStagiaireResponse.newBuilder()
                    .setMessage("Stagiaire Deleted").build();
            responseObserver.onNext(deleteStagiaireResponse);
            responseObserver.onCompleted();
        } else {
            responseObserver.onError(Status.INTERNAL.withDescription("Stagiaire not found").asException());
        }
    }
}
