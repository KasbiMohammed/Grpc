package com.expose.grpc.stubs;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: Stagiaire.proto")
public final class StagiaireServiceGrpc {

  private StagiaireServiceGrpc() {}

  public static final String SERVICE_NAME = "StagiaireService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.expose.grpc.stubs.StagiaireOuterClass.Empty,
      com.expose.grpc.stubs.StagiaireOuterClass.ListStagiairesResponse> getListStagiairesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListStagiaires",
      requestType = com.expose.grpc.stubs.StagiaireOuterClass.Empty.class,
      responseType = com.expose.grpc.stubs.StagiaireOuterClass.ListStagiairesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.expose.grpc.stubs.StagiaireOuterClass.Empty,
      com.expose.grpc.stubs.StagiaireOuterClass.ListStagiairesResponse> getListStagiairesMethod() {
    io.grpc.MethodDescriptor<com.expose.grpc.stubs.StagiaireOuterClass.Empty, com.expose.grpc.stubs.StagiaireOuterClass.ListStagiairesResponse> getListStagiairesMethod;
    if ((getListStagiairesMethod = StagiaireServiceGrpc.getListStagiairesMethod) == null) {
      synchronized (StagiaireServiceGrpc.class) {
        if ((getListStagiairesMethod = StagiaireServiceGrpc.getListStagiairesMethod) == null) {
          StagiaireServiceGrpc.getListStagiairesMethod = getListStagiairesMethod = 
              io.grpc.MethodDescriptor.<com.expose.grpc.stubs.StagiaireOuterClass.Empty, com.expose.grpc.stubs.StagiaireOuterClass.ListStagiairesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "StagiaireService", "ListStagiaires"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.expose.grpc.stubs.StagiaireOuterClass.Empty.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.expose.grpc.stubs.StagiaireOuterClass.ListStagiairesResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new StagiaireServiceMethodDescriptorSupplier("ListStagiaires"))
                  .build();
          }
        }
     }
     return getListStagiairesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.expose.grpc.stubs.StagiaireOuterClass.GetStagiaireRequest,
      com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> getGetStagiaireMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetStagiaire",
      requestType = com.expose.grpc.stubs.StagiaireOuterClass.GetStagiaireRequest.class,
      responseType = com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.expose.grpc.stubs.StagiaireOuterClass.GetStagiaireRequest,
      com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> getGetStagiaireMethod() {
    io.grpc.MethodDescriptor<com.expose.grpc.stubs.StagiaireOuterClass.GetStagiaireRequest, com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> getGetStagiaireMethod;
    if ((getGetStagiaireMethod = StagiaireServiceGrpc.getGetStagiaireMethod) == null) {
      synchronized (StagiaireServiceGrpc.class) {
        if ((getGetStagiaireMethod = StagiaireServiceGrpc.getGetStagiaireMethod) == null) {
          StagiaireServiceGrpc.getGetStagiaireMethod = getGetStagiaireMethod = 
              io.grpc.MethodDescriptor.<com.expose.grpc.stubs.StagiaireOuterClass.GetStagiaireRequest, com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "StagiaireService", "GetStagiaire"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.expose.grpc.stubs.StagiaireOuterClass.GetStagiaireRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire.getDefaultInstance()))
                  .setSchemaDescriptor(new StagiaireServiceMethodDescriptorSupplier("GetStagiaire"))
                  .build();
          }
        }
     }
     return getGetStagiaireMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.expose.grpc.stubs.StagiaireOuterClass.Empty,
      com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> getListStagiairesStreamMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListStagiairesStream",
      requestType = com.expose.grpc.stubs.StagiaireOuterClass.Empty.class,
      responseType = com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.expose.grpc.stubs.StagiaireOuterClass.Empty,
      com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> getListStagiairesStreamMethod() {
    io.grpc.MethodDescriptor<com.expose.grpc.stubs.StagiaireOuterClass.Empty, com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> getListStagiairesStreamMethod;
    if ((getListStagiairesStreamMethod = StagiaireServiceGrpc.getListStagiairesStreamMethod) == null) {
      synchronized (StagiaireServiceGrpc.class) {
        if ((getListStagiairesStreamMethod = StagiaireServiceGrpc.getListStagiairesStreamMethod) == null) {
          StagiaireServiceGrpc.getListStagiairesStreamMethod = getListStagiairesStreamMethod = 
              io.grpc.MethodDescriptor.<com.expose.grpc.stubs.StagiaireOuterClass.Empty, com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "StagiaireService", "ListStagiairesStream"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.expose.grpc.stubs.StagiaireOuterClass.Empty.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire.getDefaultInstance()))
                  .setSchemaDescriptor(new StagiaireServiceMethodDescriptorSupplier("ListStagiairesStream"))
                  .build();
          }
        }
     }
     return getListStagiairesStreamMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.expose.grpc.stubs.StagiaireOuterClass.CreateStagiaireRequest,
      com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> getCreateStagiaireMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateStagiaire",
      requestType = com.expose.grpc.stubs.StagiaireOuterClass.CreateStagiaireRequest.class,
      responseType = com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.expose.grpc.stubs.StagiaireOuterClass.CreateStagiaireRequest,
      com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> getCreateStagiaireMethod() {
    io.grpc.MethodDescriptor<com.expose.grpc.stubs.StagiaireOuterClass.CreateStagiaireRequest, com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> getCreateStagiaireMethod;
    if ((getCreateStagiaireMethod = StagiaireServiceGrpc.getCreateStagiaireMethod) == null) {
      synchronized (StagiaireServiceGrpc.class) {
        if ((getCreateStagiaireMethod = StagiaireServiceGrpc.getCreateStagiaireMethod) == null) {
          StagiaireServiceGrpc.getCreateStagiaireMethod = getCreateStagiaireMethod = 
              io.grpc.MethodDescriptor.<com.expose.grpc.stubs.StagiaireOuterClass.CreateStagiaireRequest, com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "StagiaireService", "CreateStagiaire"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.expose.grpc.stubs.StagiaireOuterClass.CreateStagiaireRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire.getDefaultInstance()))
                  .setSchemaDescriptor(new StagiaireServiceMethodDescriptorSupplier("CreateStagiaire"))
                  .build();
          }
        }
     }
     return getCreateStagiaireMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire,
      com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> getUpdateStagiaireMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateStagiaire",
      requestType = com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire.class,
      responseType = com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire,
      com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> getUpdateStagiaireMethod() {
    io.grpc.MethodDescriptor<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire, com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> getUpdateStagiaireMethod;
    if ((getUpdateStagiaireMethod = StagiaireServiceGrpc.getUpdateStagiaireMethod) == null) {
      synchronized (StagiaireServiceGrpc.class) {
        if ((getUpdateStagiaireMethod = StagiaireServiceGrpc.getUpdateStagiaireMethod) == null) {
          StagiaireServiceGrpc.getUpdateStagiaireMethod = getUpdateStagiaireMethod = 
              io.grpc.MethodDescriptor.<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire, com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "StagiaireService", "UpdateStagiaire"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire.getDefaultInstance()))
                  .setSchemaDescriptor(new StagiaireServiceMethodDescriptorSupplier("UpdateStagiaire"))
                  .build();
          }
        }
     }
     return getUpdateStagiaireMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireRequest,
      com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireResponse> getDeleteStagiaireMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteStagiaire",
      requestType = com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireRequest.class,
      responseType = com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireRequest,
      com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireResponse> getDeleteStagiaireMethod() {
    io.grpc.MethodDescriptor<com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireRequest, com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireResponse> getDeleteStagiaireMethod;
    if ((getDeleteStagiaireMethod = StagiaireServiceGrpc.getDeleteStagiaireMethod) == null) {
      synchronized (StagiaireServiceGrpc.class) {
        if ((getDeleteStagiaireMethod = StagiaireServiceGrpc.getDeleteStagiaireMethod) == null) {
          StagiaireServiceGrpc.getDeleteStagiaireMethod = getDeleteStagiaireMethod = 
              io.grpc.MethodDescriptor.<com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireRequest, com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "StagiaireService", "DeleteStagiaire"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new StagiaireServiceMethodDescriptorSupplier("DeleteStagiaire"))
                  .build();
          }
        }
     }
     return getDeleteStagiaireMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static StagiaireServiceStub newStub(io.grpc.Channel channel) {
    return new StagiaireServiceStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static StagiaireServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new StagiaireServiceBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static StagiaireServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new StagiaireServiceFutureStub(channel);
  }

  /**
   */
  public static abstract class StagiaireServiceImplBase implements io.grpc.BindableService {

    /**
     */
    public void listStagiaires(com.expose.grpc.stubs.StagiaireOuterClass.Empty request,
        io.grpc.stub.StreamObserver<com.expose.grpc.stubs.StagiaireOuterClass.ListStagiairesResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getListStagiairesMethod(), responseObserver);
    }

    /**
     */
    public void getStagiaire(com.expose.grpc.stubs.StagiaireOuterClass.GetStagiaireRequest request,
        io.grpc.stub.StreamObserver<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> responseObserver) {
      asyncUnimplementedUnaryCall(getGetStagiaireMethod(), responseObserver);
    }

    /**
     */
    public void listStagiairesStream(com.expose.grpc.stubs.StagiaireOuterClass.Empty request,
        io.grpc.stub.StreamObserver<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> responseObserver) {
      asyncUnimplementedUnaryCall(getListStagiairesStreamMethod(), responseObserver);
    }

    /**
     */
    public void createStagiaire(com.expose.grpc.stubs.StagiaireOuterClass.CreateStagiaireRequest request,
        io.grpc.stub.StreamObserver<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> responseObserver) {
      asyncUnimplementedUnaryCall(getCreateStagiaireMethod(), responseObserver);
    }

    /**
     */
    public void updateStagiaire(com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire request,
        io.grpc.stub.StreamObserver<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> responseObserver) {
      asyncUnimplementedUnaryCall(getUpdateStagiaireMethod(), responseObserver);
    }

    /**
     */
    public void deleteStagiaire(com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireRequest request,
        io.grpc.stub.StreamObserver<com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getDeleteStagiaireMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getListStagiairesMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                com.expose.grpc.stubs.StagiaireOuterClass.Empty,
                com.expose.grpc.stubs.StagiaireOuterClass.ListStagiairesResponse>(
                  this, METHODID_LIST_StagiaireS)))
          .addMethod(
            getGetStagiaireMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                com.expose.grpc.stubs.StagiaireOuterClass.GetStagiaireRequest,
                com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire>(
                  this, METHODID_GET_Stagiaire)))
          .addMethod(
            getListStagiairesStreamMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                com.expose.grpc.stubs.StagiaireOuterClass.Empty,
                com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire>(
                  this, METHODID_LIST_StagiaireS_STREAM)))
          .addMethod(
            getCreateStagiaireMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                com.expose.grpc.stubs.StagiaireOuterClass.CreateStagiaireRequest,
                com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire>(
                  this, METHODID_CREATE_Stagiaire)))
          .addMethod(
            getUpdateStagiaireMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire,
                com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire>(
                  this, METHODID_UPDATE_Stagiaire)))
          .addMethod(
            getDeleteStagiaireMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireRequest,
                com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireResponse>(
                  this, METHODID_DELETE_Stagiaire)))
          .build();
    }
  }

  /**
   */
  public static final class StagiaireServiceStub extends io.grpc.stub.AbstractStub<StagiaireServiceStub> {
    private StagiaireServiceStub(io.grpc.Channel channel) {
      super(channel);
    }

    private StagiaireServiceStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected StagiaireServiceStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new StagiaireServiceStub(channel, callOptions);
    }

    /**
     */
    public void listStagiaires(com.expose.grpc.stubs.StagiaireOuterClass.Empty request,
        io.grpc.stub.StreamObserver<com.expose.grpc.stubs.StagiaireOuterClass.ListStagiairesResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getListStagiairesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getStagiaire(com.expose.grpc.stubs.StagiaireOuterClass.GetStagiaireRequest request,
        io.grpc.stub.StreamObserver<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetStagiaireMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void listStagiairesStream(com.expose.grpc.stubs.StagiaireOuterClass.Empty request,
        io.grpc.stub.StreamObserver<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getListStagiairesStreamMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createStagiaire(com.expose.grpc.stubs.StagiaireOuterClass.CreateStagiaireRequest request,
        io.grpc.stub.StreamObserver<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getCreateStagiaireMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateStagiaire(com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire request,
        io.grpc.stub.StreamObserver<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getUpdateStagiaireMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteStagiaire(com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireRequest request,
        io.grpc.stub.StreamObserver<com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getDeleteStagiaireMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   */
  public static final class StagiaireServiceBlockingStub extends io.grpc.stub.AbstractStub<StagiaireServiceBlockingStub> {
    private StagiaireServiceBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private StagiaireServiceBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected StagiaireServiceBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new StagiaireServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public com.expose.grpc.stubs.StagiaireOuterClass.ListStagiairesResponse listStagiaires(com.expose.grpc.stubs.StagiaireOuterClass.Empty request) {
      return blockingUnaryCall(
          getChannel(), getListStagiairesMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire getStagiaire(com.expose.grpc.stubs.StagiaireOuterClass.GetStagiaireRequest request) {
      return blockingUnaryCall(
          getChannel(), getGetStagiaireMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> listStagiairesStream(
        com.expose.grpc.stubs.StagiaireOuterClass.Empty request) {
      return blockingServerStreamingCall(
          getChannel(), getListStagiairesStreamMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire createStagiaire(com.expose.grpc.stubs.StagiaireOuterClass.CreateStagiaireRequest request) {
      return blockingUnaryCall(
          getChannel(), getCreateStagiaireMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire updateStagiaire(com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire request) {
      return blockingUnaryCall(
          getChannel(), getUpdateStagiaireMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireResponse deleteStagiaire(com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireRequest request) {
      return blockingUnaryCall(
          getChannel(), getDeleteStagiaireMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class StagiaireServiceFutureStub extends io.grpc.stub.AbstractStub<StagiaireServiceFutureStub> {
    private StagiaireServiceFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private StagiaireServiceFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected StagiaireServiceFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new StagiaireServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.expose.grpc.stubs.StagiaireOuterClass.ListStagiairesResponse> listStagiaires(
        com.expose.grpc.stubs.StagiaireOuterClass.Empty request) {
      return futureUnaryCall(
          getChannel().newCall(getListStagiairesMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> getStagiaire(
        com.expose.grpc.stubs.StagiaireOuterClass.GetStagiaireRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getGetStagiaireMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> createStagiaire(
        com.expose.grpc.stubs.StagiaireOuterClass.CreateStagiaireRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getCreateStagiaireMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire> updateStagiaire(
        com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire request) {
      return futureUnaryCall(
          getChannel().newCall(getUpdateStagiaireMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireResponse> deleteStagiaire(
        com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getDeleteStagiaireMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_LIST_StagiaireS = 0;
  private static final int METHODID_GET_Stagiaire = 1;
  private static final int METHODID_LIST_StagiaireS_STREAM = 2;
  private static final int METHODID_CREATE_Stagiaire = 3;
  private static final int METHODID_UPDATE_Stagiaire = 4;
  private static final int METHODID_DELETE_Stagiaire = 5;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final StagiaireServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(StagiaireServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_LIST_StagiaireS:
          serviceImpl.listStagiaires((com.expose.grpc.stubs.StagiaireOuterClass.Empty) request,
              (io.grpc.stub.StreamObserver<com.expose.grpc.stubs.StagiaireOuterClass.ListStagiairesResponse>) responseObserver);
          break;
        case METHODID_GET_Stagiaire:
          serviceImpl.getStagiaire((com.expose.grpc.stubs.StagiaireOuterClass.GetStagiaireRequest) request,
              (io.grpc.stub.StreamObserver<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire>) responseObserver);
          break;
        case METHODID_LIST_StagiaireS_STREAM:
          serviceImpl.listStagiairesStream((com.expose.grpc.stubs.StagiaireOuterClass.Empty) request,
              (io.grpc.stub.StreamObserver<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire>) responseObserver);
          break;
        case METHODID_CREATE_Stagiaire:
          serviceImpl.createStagiaire((com.expose.grpc.stubs.StagiaireOuterClass.CreateStagiaireRequest) request,
              (io.grpc.stub.StreamObserver<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire>) responseObserver);
          break;
        case METHODID_UPDATE_Stagiaire:
          serviceImpl.updateStagiaire((com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire) request,
              (io.grpc.stub.StreamObserver<com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire>) responseObserver);
          break;
        case METHODID_DELETE_Stagiaire:
          serviceImpl.deleteStagiaire((com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireRequest) request,
              (io.grpc.stub.StreamObserver<com.expose.grpc.stubs.StagiaireOuterClass.DeleteStagiaireResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class StagiaireServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    StagiaireServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.expose.grpc.stubs.StagiaireOuterClass.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("StagiaireService");
    }
  }

  private static final class StagiaireServiceFileDescriptorSupplier
      extends StagiaireServiceBaseDescriptorSupplier {
    StagiaireServiceFileDescriptorSupplier() {}
  }

  private static final class StagiaireServiceMethodDescriptorSupplier
      extends StagiaireServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    StagiaireServiceMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (StagiaireServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new StagiaireServiceFileDescriptorSupplier())
              .addMethod(getListStagiairesMethod())
              .addMethod(getGetStagiaireMethod())
              .addMethod(getListStagiairesStreamMethod())
              .addMethod(getCreateStagiaireMethod())
              .addMethod(getUpdateStagiaireMethod())
              .addMethod(getDeleteStagiaireMethod())
              .build();
        }
      }
    }
    return result;
  }
}
