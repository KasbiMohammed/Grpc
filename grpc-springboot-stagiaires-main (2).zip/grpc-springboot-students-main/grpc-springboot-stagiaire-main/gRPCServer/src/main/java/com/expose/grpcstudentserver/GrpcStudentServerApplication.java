package com.expose.grpcStagiaireserver;

import com.expose.entities.Stagiaire;
import com.expose.repositories.StagiaireRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EntityScan(basePackages = {"com.expose.entities"})
@ComponentScan(basePackages = {
        "com.expose.grpc.services",
        "com.expose.mappers",
        "com.expose.repositories",
        "com.expose.grpc.interceptors"
})
@EnableJpaRepositories(basePackages = {"com.expose.repositories"})
public class GrpcStagiaireServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(GrpcStagiaireServerApplication.class, args);
    }

    @Bean
    public CommandLineRunner startup(StagiaireRepository StagiaireRepository) {
        return args -> {
            for (int i = 1; i <= 10; i++) {
                StagiaireRepository.save(Stagiaire.builder().Nom("kasbi " + i).Prenom("mohammed " + i).dateEntree((Date)).build());
            }
        };
    }
}
