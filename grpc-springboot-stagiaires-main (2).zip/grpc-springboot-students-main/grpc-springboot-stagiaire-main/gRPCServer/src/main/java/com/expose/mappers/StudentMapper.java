package com.expose.mappers;

import org.springframework.stereotype.Component;

import com.expose.entities.Stagiaire;

@Component
public class StagiaireMapper {
    public com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire toGrpcStagiaire(Stagiaire Stagiaire) {
        return com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire.newBuilder().setId(Stagiaire.getId())
                .setFirstName(Stagiaire.getNom())
                .setLastName(Stagiaire.getPrenom())
                .setAge(Stagiaire.getDateEntree())
                .build();
    }

    public Stagiaire fromGrpcStagiaire(com.expose.grpc.stubs.StagiaireOuterClass.Stagiaire Stagiaire) {
        return Stagiaire.builder()
                .id(Stagiaire.getId())
                .Nom(Stagiaire.getNom())
                .Prenom(Stagiaire.getPrenom())
                .DateEntree(Stagiaire.getDateEntree())
                .build();
    }
}
