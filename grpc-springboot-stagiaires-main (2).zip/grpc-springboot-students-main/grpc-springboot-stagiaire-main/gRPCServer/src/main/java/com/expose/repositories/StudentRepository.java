package com.expose.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.a00n.entities.Student;

@Repository
public interface StagiaireRepository extends JpaRepository<Stagiaire, int> {

}
