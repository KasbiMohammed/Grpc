package com.expose.grpcStagiaireserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrpcStagiaireServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
