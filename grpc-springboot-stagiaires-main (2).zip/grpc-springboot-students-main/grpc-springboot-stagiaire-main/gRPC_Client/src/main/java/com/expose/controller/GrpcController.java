package com.expose.controller;

import com.expose.entities.CustomResponse;
import com.expose.entities.Stagiaire;
import com.expose.grpc.stubs.StagiaireOuterClass;
import com.expose.service.GrpcClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/Stagiaires")
public class GrpcController {

    private GrpcClientService grpcStagiaireClient;

    @Autowired
    public GrpcController(GrpcClientService grpcStagiaireClient) {
        this.grpcStagiaireClient = grpcStagiaireClient;
    }

    @GetMapping
    public ResponseEntity<List<Stagiaire>> getStagiaireList() {
        try {
            // Call gRPC service to get a list of Stagiaires
            StagiaireOuterClass.ListStagiairesResponse StagiaireList = grpcStagiaireClient.listStagiaires();

            // Convert gRPC response to entitiess
            List<Stagiaire> responseList = new ArrayList<>();
            for (StagiaireOuterClass.Stagiaire Stagiaire : StagiaireList.getStagiairesList()) {
                Stagiaire Stagiaireentities = new Stagiaire();
                Stagiaireentities.setId(Stagiaire.getId());
                Stagiaireentities.setFirstName(Stagiaire.getFirstName());
                Stagiaireentities.setLastName(Stagiaire.getLastName());
                Stagiaireentities.setAge(Stagiaire.getAge());

                responseList.add(Stagiaireentities);
            }

            return ResponseEntity.ok(responseList);
        } catch (Exception e) {
            // Handle the exception, you can log it or return a specific error response
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @GetMapping(value = "/{id}")
        public ResponseEntity<Stagiaire> getStagiaireById(@PathVariable Long id) {

        try{
            StagiaireOuterClass.Stagiaire Stagiaire = grpcStagiaireClient.getStagiaireById(id);
            // Convert gRPC response to entities
            Stagiaire createdStagiaireentities = new Stagiaire();
            createdStagiaireentities.setId(Stagiaire.getId());
            createdStagiaireentities.setFirstName(Stagiaire.getFirstName());
            createdStagiaireentities.setLastName(Stagiaire.getLastName());
            createdStagiaireentities.setAge(Stagiaire.getAge());
            return ResponseEntity.ok(createdStagiaireentities);

        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

    @GetMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<Stagiaire> streamStagiaires() {
        return Flux.fromStream(grpcStagiaireClient.listStagiairesStream().toStream())
            .map(Stagiaire -> {
                Stagiaire Stagiaireentities = new Stagiaire();
                Stagiaireentities.setId(Stagiaire.getId());
                Stagiaireentities.setFirstName(Stagiaire.getFirstName());
                Stagiaireentities.setLastName(Stagiaire.getLastName());
                Stagiaireentities.setAge(Stagiaire.getAge());
                return Stagiaireentities;
            });

//        return Flux.interval(Duration.ofSeconds(5))
//                .publishOn(Schedulers.boundedElastic())
//                .flatMap(sequence -> {
//                    // Convert the gRPC stream to a Flux
//                    Flux<StagiaireOuterClass.Stagiaire> grpcStagiaireStream = Flux.fromStream(grpcStagiaireClient.listStagiairesStream().toStream());
//
//                    // Map each gRPC Stagiaire to a Stagiaire entities
//                    return grpcStagiaireStream.map(Stagiaire -> {
//                        Stagiaire Stagiaireentities = new Stagiaire();
//                        Stagiaireentities.setId(Stagiaire.getId());
//                        Stagiaireentities.setFirstName(Stagiaire.getFirstNname());
//                        Stagiaireentities.setLastName(Stagiaire.getLastName());
//                        Stagiaireentities.setAge(Stagiaire.getAge());
//                        return Stagiaireentities;
//                    });
//                });
    }


    @PostMapping
    public ResponseEntity<Stagiaire> createStagiaire(@RequestBody Stagiaire request) {
        String firstName = request.getFirstName();
        String lastName = request.getLastName();
        long age = request.getAge();
        System.out.println(firstName);
        StagiaireOuterClass.Stagiaire createdStagiaire = grpcStagiaireClient.createStagiaire(firstName, lastName, age);

        // Convert gRPC response to entities
        Stagiaire createdStagiaireentities = new Stagiaire();
        createdStagiaireentities.setId(createdStagiaire.getId());
        createdStagiaireentities.setFirstName(createdStagiaire.getFirstName());
        createdStagiaireentities.setLastName(createdStagiaire.getLastName());
        createdStagiaireentities.setAge(createdStagiaire.getAge());

        return ResponseEntity.ok(createdStagiaireentities);
    }


    @PutMapping("/{id}")
    public ResponseEntity<Stagiaire> updateStagiaire(@PathVariable Long id, @RequestBody Stagiaire updatedStagiaireentities) {
        StagiaireOuterClass.Stagiaire updatedStagiaire = StagiaireOuterClass.Stagiaire.newBuilder()
            .setId(id)
            .setFirstName(updatedStagiaireentities.getFirstName())
            .setLastName(updatedStagiaireentities.getLastName())
            .setAge(updatedStagiaireentities.getAge())
            .build();

        // Call gRPC service to update Stagiaire
        StagiaireOuterClass.Stagiaire updatedStagiaireResponse = grpcStagiaireClient.updateStagiaire(updatedStagiaire);

        // Convert gRPC response to entities
        Stagiaire updatedStagiaireResponseentities = new Stagiaire();
        updatedStagiaireResponseentities.setId(updatedStagiaireResponse.getId());
        updatedStagiaireResponseentities.setFirstName(updatedStagiaireResponse.getFirstName());
        updatedStagiaireResponseentities.setLastName(updatedStagiaireResponse.getLastName());
        updatedStagiaireResponseentities.setAge(updatedStagiaireResponse.getAge());

        return ResponseEntity.ok(updatedStagiaireResponseentities);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteStagiaire(@PathVariable Long id) {
        // Call gRPC service to delete Stagiaire
        StagiaireOuterClass.DeleteStagiaireResponse deleteResponse = grpcStagiaireClient.deleteStagiaire(id);

        // Check if the deletion was successful
        if (deleteResponse != null && "Stagiaire Deleted".equalsIgnoreCase(deleteResponse.getMessage())) {
            return ResponseEntity.ok("Stagiaire deleted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to delete Stagiaire.");
        }
    }

}
