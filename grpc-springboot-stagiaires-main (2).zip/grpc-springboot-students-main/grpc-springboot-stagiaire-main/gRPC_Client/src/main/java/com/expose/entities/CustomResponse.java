package com.expose.entities;

public class CustomResponse {
    private Stagere Stagere;
    private String message;

    public CustomResponse(Stagere Stagere, String message) {
    }


    public Stagere getStagere() {
        return Stagere;
    }

    public void setStagere(Stagere stagere) {
        this.stagere = stagere;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

