package com.expose.service;

import com.google.protobuf.Empty;
import com.leeuw.grpc.stubs.StagiaireOuterClass;
import com.leeuw.grpc.stubs.StagiaireServiceGrpc;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.FluxSink;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Service
public class GrpcClientService {
    @GrpcClient("service")
    StagiaireServiceGrpc.StagiaireServiceBlockingStub StagiaireServiceStub;

    @GrpcClient("service")
    StagiaireServiceGrpc.StagiaireServiceStub asyncStagiaireServiceStub;
    public StagiaireOuterClass.ListStagiairesResponse listStagiaires() {
        return StagiaireServiceStub.listStagiaires(StagiaireOuterClass.Empty.newBuilder().build());
    }

    public Flux<StagiaireOuterClass.Stagiaire> listStagiairesStream() {
        // Use Flux.create to handle the asynchronous nature of gRPC streaming
        return Flux.create(emitter -> {
            asyncStagiaireServiceStub.listStagiairesStream(StagiaireOuterClass.Empty.newBuilder().build(),
                new StreamObserver<StagiaireOuterClass.Stagiaire>() {
                    @Override
                    public void onNext(StagiaireOuterClass.Stagiaire Stagiaire) {
                        // Emit each Stagiaire to the Flux
                        emitter.next(Stagiaire);
                    }

                    @Override
                    public void onError(Throwable throwable) {
                        // Signal error to the Flux
                        emitter.error(throwable);
                    }

                    @Override
                    public void onCompleted() {
                        // Signal completion to the Flux
                        emitter.complete();
                    }
                });
        }, FluxSink.OverflowStrategy.BUFFER);
    }




    public StagiaireOuterClass.Stagiaire getStagiaireById(long id) {
        StagiaireOuterClass.GetStagiaireRequest request = StagiaireOuterClass.GetStagiaireRequest.newBuilder().setId(id).build();
        return StagiaireServiceStub.getStagiaire(request);
    }

    public StagiaireOuterClass.Stagiaire createStagiaire(String firstName, String lastName, long age) {
        StagiaireOuterClass.CreateStagiaireRequest request = StagiaireOuterClass.CreateStagiaireRequest.newBuilder()
            .setFirstName(firstName)
            .setLastName(lastName)
            .setAge(age)
            .build();

        return StagiaireServiceStub.createStagiaire(request);
    }

    public StagiaireOuterClass.Stagiaire updateStagiaire(StagiaireOuterClass.Stagiaire Stagiaire) {
        return StagiaireServiceStub.updateStagiaire(Stagiaire);
    }

    public StagiaireOuterClass.DeleteStagiaireResponse deleteStagiaire(long id) {
        StagiaireOuterClass.DeleteStagiaireRequest request = StagiaireOuterClass.DeleteStagiaireRequest.newBuilder().setId(id).build();
        return StagiaireServiceStub.deleteStagiaire(request);
    }
}

